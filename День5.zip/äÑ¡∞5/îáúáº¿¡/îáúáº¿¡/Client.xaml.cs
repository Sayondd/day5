﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Магазин.bd;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class Client : Window
    {
        private Product[] products;
        private int totalCount;
        private int currentCount;
        public Client()
        {
            InitializeComponent();
            RefreshData();
        }
        private Product[] SortProduct(Product[] product)//сортировка
        {
            try
            {
                if (sort.SelectedIndex == 0)
                    product = product.ToArray();
                if (sort.SelectedIndex == 1)
                    product = product.OrderBy(c => c.Price).ToArray();//по возрастанию
                if (sort.SelectedIndex == 2)
                    product = product.
                        OrderByDescending(c => c.Price).ToArray();//по убыванию
            }
            catch { }
            return product;
        }

        private Product[] FilterProduct(Product[] product)//фильтрация
        {
            try
            {
                if (filtr.SelectedIndex == 0)
                    product = product.ToArray();
                if (filtr.SelectedIndex == 1)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "БТК Текстиль").ToArray();
                if (filtr.SelectedIndex == 2)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Империя ткани").ToArray();
                if (filtr.SelectedIndex == 3)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Комильфо").ToArray();
                if (filtr.SelectedIndex == 4)
                    product = product.Where(c => c.Manufactured
                    .ManufacturedName == "Май Фабрик").ToArray();
            }
            catch { }
            return product;
        }
        private Product[] SearchProduct(Product[] product)//поиск
        {
            try
            {
                if (search.Text != null)
                {
                    product = product.Where(c => c.ProductName.ToLower().
                    Contains(search.Text.ToLower()) |
                    c.ProductArticleNumber.ToLower().
                    Contains(search.Text.ToLower()) |
                     c.Description.ToLower().
                    Contains(search.Text.ToLower()) |
                     c.Manufactured.ManufacturedName.ToLower().
                    Contains(search.Text.ToLower())).ToArray();
                }
                if (product.Length == 0)
                {
                    ListViewItems.ItemsSource = product;
                    MessageBox.Show("Товаров с таким данными не найдено");
                }
            }
            catch { }

            return product;
        }

        private void RefreshData()//метод для вывода данных 
        {

            products = App.entities.Products.ToArray();
            products = SortProduct(products);
            products = FilterProduct(products);
            products = SearchProduct(products);
            ListViewItems.ItemsSource = products.ToList();
            totalCount = App.entities.Products.Count();
            currentCount = products.Count();
            countService.Content = $"{currentCount} / {totalCount}";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void search_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshData();
        }

        private void filtr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }
    }
}
