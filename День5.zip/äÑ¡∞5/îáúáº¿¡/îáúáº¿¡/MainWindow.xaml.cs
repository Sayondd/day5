﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        int Attempts;
        DateTime now = DateTime.Now;//текущие дата и время  
        int idUser;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var ForUsers = App.entities.Users.FirstOrDefault
                    (x => x.UserLogin == login.Text &&
                    x.UserPassword == pass.Password);//для входа
                int idUser = App.entities.Users.Where(c => c.UserLogin == login.Text).Select(c => c.UserID).FirstOrDefault();
                if (login == null || pass == null)
                {
                    MessageBox.Show("Заполните данные!");
                }
                else
                {
                    if (ForUsers != null)
                    {
                        switch (ForUsers.UserRole)
                        {
                            case 1://Администратор
                                Admin showAdmin = new Admin();
                                showAdmin.Show();
                                this.Close();
                                break;
                            case 2://Бухгалтер
                                Client client = new Client();
                                client.Show();
                                this.Close();
                                break;
                            case 3://Организатор
                                Client c = new Client();
                                c.Show();
                                this.Close();
                                break;
                        }
                    }
                    else
                    {
                        Attempts++;
                        UsersFalse(); 
                    }
                }
            }
            catch { }

        }
        System.Windows.Threading.DispatcherTimer timer1 = new System.Windows.Threading.DispatcherTimer();
        public void UsersFalse()//Блок неверной капчи
        {
            if (Attempts == 1 || Attempts == 2)
            {
                MessageBoxResult result = MessageBox.Show("Неверно введёт логин или пароль." +
                    "\nПроверьте введённые вами данные!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Attempts == 3)
            {
                Capcha captha = new Capcha();
                captha.ShowDialog();
            }
            if (Attempts >= 4)//если пользователь продолжает вводить неверно логин и пароль
            {//вход продолжает блокироваться на 10 секунд
                timer1.Tick += new EventHandler(timerTick2);
                timer1.Interval = new TimeSpan(0, 0, 1);
                timer1.Start();
                if (stop != 0)
                {
                    login.IsEnabled = false;
                    pass.IsEnabled = false;
                    pas.IsEnabled = false;
                    //Authoriz.IsEnabled = false;
                    MessageBox.Show(String.Format("Вход заблокирован на {0:0} секунд", stop));
                }
            }
        }
        int stop = 10;
        private void timerTick2(object sender, EventArgs e)//Блокировка входа и заполнения при последующих неверных входах
        {
            if (stop == 0)
            {
                login.IsEnabled = true;
                pass.IsEnabled = true;
                pas.IsEnabled = true;
                MessageBoxResult result = MessageBox.Show("Время вышло!\nПовторите вход заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer1.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }
        private void check_Click(object sender, RoutedEventArgs e)
        {
            if (check.IsChecked == true)
            {
                pas.Text = pass.Password;
                pas.Visibility = Visibility.Visible;
                pass.Visibility = Visibility.Collapsed;
            }
            else
            {
                pass.Password = pas.Text;
                pas.Visibility = Visibility.Collapsed;
                pass.Visibility = Visibility.Visible;
            }
        }
    }
}
