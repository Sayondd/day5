﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Магазин.bd;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для editProduct.xaml
    /// </summary>
    public partial class editProduct : Window
    {
        bd.Product product;
        public editProduct(Product product)
        {
            InitializeComponent();
            this.product = product;
            this.DataContext = product;
            identity = product.ProductArticleNumber;
            List<Product> products = App.entities.Products.
                Where(x => x.ProductArticleNumber == identity).ToList();
            cbCategory.ItemsSource = App.entities.Categories.
               Select(c => c.CategoryName).ToList();
            cbManufacturer.ItemsSource = App.entities.Manufactureds.
                Select(c => c.ManufacturedName).ToList();
            cbSupplier.ItemsSource = App.entities.Suppliers.
                Select(c => c.SuppliersName).ToList();
            cbUnitOfMeasurement.ItemsSource = App.entities.Units.
                Select(c => c.UnitName).ToList();
        }
        string identity; 
        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbArticle.Text == "" | tbName.Text == "" | tbDescription.Text == "" | cbCategory.Text == "" | cbManufacturer.Text == ""
                    | tbCost.Text == "" | tbDescription.Text == "" | tbQuantityInStock.Text == "" | tbMaxDiscount.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int categoryID = App.entities.Categories.
                       Where(x => x.CategoryName == cbCategory.Text).
                       Select(x => x.idCategory).FirstOrDefault();
                    int manufacturerID = App.entities.Manufactureds.
                        Where(x => x.ManufacturedName == cbManufacturer.Text).
                        Select(x => x.idManufactured).FirstOrDefault();
                    int unitOfMeasurrementID = App.entities.Units.
                        Where(x => x.UnitName == cbUnitOfMeasurement.Text).
                        Select(x => x.idUnit).FirstOrDefault();
                    int suppliersID = App.entities.Suppliers.
                        Where(x => x.SuppliersName == cbSupplier.Text).
                        Select(x => x.idSuppliers).FirstOrDefault();
                    List<Product> products = App.entities.Products.Where(x => x.ProductArticleNumber == identity).ToList();
                    try
                    {
                        products[0].ProductArticleNumber = tbArticle.Text;
                        products[0].ProductName = tbName.Text;
                        products[0].Description = tbDescription.Text;
                        products[0].idCategory = categoryID;
                        products[0].idManufactured = manufacturerID;
                        products[0].Price = Convert.ToDecimal(tbCost.Text);
                        products[0].CurrentDiscount = Convert.ToInt32(tbDiscount.Text);
                        products[0].QuantityStock = Convert.ToInt32(tbQuantityInStock.Text);
                        products[0].MaximumDiscountSize = Convert.ToInt32(tbMaxDiscount.Text);
                        products[0].idSuppliers = suppliersID;
                    }
                    catch { }
                    App.entities.Products.AddOrUpdate();
                    App.entities.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
